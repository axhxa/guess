package com.example.android_guess;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    TextView text1,text2;
    EditText edittext1;
    Button btn1;
    ImageView imgy,imgn,imgu,imgd;
    int num=5050;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext1=(EditText)findViewById(R.id.editText1);
        text1=(TextView)findViewById(R.id.textView1);
        text2=(TextView)findViewById(R.id.textView2);
        btn1=(Button) findViewById(R.id.button1);
        imgy=(ImageView)findViewById(R.id.imageyes);
        imgn=(ImageView)findViewById(R.id.imageno);
        imgu=(ImageView)findViewById(R.id.imageu);
        imgd=(ImageView)findViewById(R.id.imaged);
        //addListenerOnButton();
    }

    public void onclicktext(View v){
        String str=edittext1.getText().toString();
        int t=Integer.parseInt(str);
        text2.setVisibility(View.GONE);
        text1.setVisibility(View.VISIBLE);
        imgn.setVisibility(View.GONE);
        imgy.setVisibility(View.GONE);
        imgu.setVisibility(View.INVISIBLE);
        imgd.setVisibility(View.INVISIBLE);
        if(t>1&&t<9999){
            btn1.setVisibility(View.VISIBLE);
        }
    }

    public void onclick(View v){
        String str=edittext1.getText().toString();
        int t=Integer.parseInt(str);
        if(t<num){
            btn1.setVisibility(View.GONE);
            text1.setVisibility(View.GONE);
            text2.setVisibility(View.VISIBLE);
            imgn.setVisibility(View.VISIBLE);
            imgd.setVisibility(View.VISIBLE);
        }
        if(t>num){
            text1.setVisibility(View.GONE);
            text2.setVisibility(View.VISIBLE);
            btn1.setVisibility(View.GONE);
            imgn.setVisibility(View.VISIBLE);
            imgu.setVisibility(View.VISIBLE);
        }
        if(t==num){
            btn1.setVisibility(View.GONE);
            imgy.setVisibility(View.VISIBLE);
        }
    }

    /*private void addListenerOnButton() {
        edittext1=(EditText)findViewById(R.id.editText1);
        btn1=(Button)findViewById(R.id.button1);
        btn1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String str=edittext1.getText().toString();
                int t=Integer.parseInt(str);
            }
        }
        );
    }*/
}
